package com.dila.tiktokpro

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Black = Color(0xFF07100A)
private val Panel = Color(0xFF102117)
private val Green = Color(0xFF39F56A)
private val Muted = Color(0xFFB8C9BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DilaApp() }
    }
}

@Composable
fun DilaApp() {
    var tab by remember { mutableStateOf(0) }
    var videoLink by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("Demo mode: real likes are not delivered by this starter app.") }
    val context = LocalContext.current

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Black, surface = Panel,
        onPrimary = Black, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Black, bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("Home") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Star, null) }, label = { Text("Community") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Visibility, null) }, label = { Text("Grow") })
            }
        }) { pad ->
            Column(
                Modifier.fillMaxSize().padding(pad).background(Black)
                    .verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("DILA TIK TOK PRO", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Green)
                Text("Free tools for TikTok creators", color = Muted)
                when (tab) {
                    0 -> {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("DAILY GOAL", color = Muted)
                                Text("Up to 200 likes goal", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Green)
                                Text("This is a planning goal, not a guaranteed like delivery.", color = Muted)
                                LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth(), color = Green)
                            }
                        }
                        Text("Add your TikTok video link", fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = videoLink, onValueChange = { videoLink = it },
                            modifier = Modifier.fillMaxWidth(), placeholder = { Text("https://vt.tiktok.com/...") },
                            singleLine = true
                        )
                        Button(onClick = {
                            val valid = videoLink.startsWith("https://") && (videoLink.contains("tiktok.com"))
                            if (valid) {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(videoLink))
                                context.startActivity(intent)
                                note = "Opened your TikTok link. Likes are not automatically added."
                            } else note = "Please enter a valid https TikTok video link."
                        }, modifier = Modifier.fillMaxWidth()) { Text("Open TikTok Video") }
                        InfoCard("Community tasks", "Explore creator tips and optional feedback tasks. This starter does not exchange or generate likes automatically.")
                        InfoCard("Safety", "Never enter your TikTok password or OTP into third-party sites.")
                        Text(note, color = Muted, fontSize = 13.sp)
                    }
                    1 -> {
                        Text("COMMUNITY", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Green)
                        InfoCard("Watch & give feedback", "Watch a public creator video and leave honest, optional feedback. No forced likes or follow-for-follow.")
                        InfoCard("Creator challenge", "Post a video using a clear hook in the first 2 seconds, then share it with friends who may genuinely enjoy it.")
                        InfoCard("Daily checklist", "• Watch 3 videos in your niche\n• Leave 2 useful comments\n• Reply to your own comments\n• Share only with people who may be interested")
                        Text("Coins and like delivery need a real backend and must not be presented as guaranteed.", color = Muted)
                    }
                    else -> {
                        Text("GROW YOUR ACCOUNT", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Green)
                        InfoCard("Hook", "Start with the most interesting moment in the first 1–2 seconds.")
                        InfoCard("Caption", "Use a short caption that invites a genuine answer.")
                        InfoCard("Posting", "Test a few posting times and compare watch time and completion rate in TikTok analytics.")
                        InfoCard("Community", "Reply to real comments and collaborate with creators in your niche.")
                        Button(onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/creator-center"))
                            context.startActivity(intent)
                        }, modifier = Modifier.fillMaxWidth()) { Text("Open TikTok Creator Center") }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("DILA TIK TOK PRO • Starter build 1.0", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = Green, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(body, color = Color(0xFFE5EEE7))
        }
    }
}
