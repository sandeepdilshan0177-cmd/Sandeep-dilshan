# DILA TIK TOK PRO — Android Studio starter

## What this starter includes
- Black/neon-green Android UI
- TikTok video link field that opens a TikTok URL
- Community creator tasks and genuine-engagement guidance
- Official TikTok growth tips and Creator Center link
- A daily 200-like *goal* display, not a promise or automatic delivery

## Important
This starter does NOT generate, purchase, exchange, or automatically deliver likes. A UI alone cannot create real TikTok engagement. Do not ask users for TikTok passwords or OTPs. Any future community/reward system should be designed to comply with TikTok's current terms and avoid forced or artificial engagement.

## Build
1. Install Android Studio.
2. Open this folder as an existing project.
3. Let Gradle sync finish (internet required for dependencies).
4. Connect an Android device or start an emulator.
5. Choose Run, or use Build > Build APK(s).

Package: `com.dila.tiktokpro`
